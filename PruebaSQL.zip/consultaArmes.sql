select * FROM employees;
