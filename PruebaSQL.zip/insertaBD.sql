use BDNilCarlos;
insert into employees(num_pass,nom) values('12345678P','Nil');
insert into employees(num_pass,nom) values('49424598J','Carlos');
insert into armesBio(nom,fecha,potencial,zona,laboratori) values('Arma1','2022-05-24',7,'Vila-seca','Lab prova');
insert into armesBio(nom,fecha,potencial,zona,laboratori) values('Arma2','2022-03-21',7,'Guatemala','Lab guatemailano');
insert into armesBio(nom,fecha,potencial,zona,laboratori) values('Arma3','2022-05-03',7,'Paraguai','Lab de paraguais');
insert into armesBio(nom,fecha,potencial,zona,laboratori) values('Arma4','2021-07-13',7,'CanyadaReal','Lab de coca');
